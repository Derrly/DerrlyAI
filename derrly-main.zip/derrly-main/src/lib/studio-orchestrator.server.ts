import { generateText, Output, type UIMessage } from "ai";
import type { SupabaseClient } from "@supabase/supabase-js";
import { z } from "zod";
import { createGroq, GROQ_MODEL } from "@/lib/groq.server";
import { AGENTS } from "@/lib/derrly-data";
import type { Database, Json } from "@/integrations/supabase/types";

type StudioClient = SupabaseClient<Database>;

const specialistIds = AGENTS.filter((agent) => agent.id !== "executive-producer").map(
  (agent) => agent.id,
);

const artifactByAgent: Record<string, { type: string; title: string; category: string }> = {
  "creative-director": {
    type: "game-design-document",
    title: "Game Design Document",
    category: "vision",
  },
  "world-architect": { type: "world-map", title: "World & Region Blueprint", category: "world" },
  "narrative-designer": { type: "story-bible", title: "Narrative Bible", category: "story" },
  "npc-designer": { type: "character-database", title: "Character Database", category: "npcs" },
  "quest-designer": { type: "quest-tree", title: "Quest & Progression Tree", category: "quests" },
  "gameplay-engineer": {
    type: "systems-blueprint",
    title: "Gameplay Systems Blueprint",
    category: "systems",
  },
  "economy-designer": {
    type: "economy-model",
    title: "Economy & Progression Model",
    category: "systems",
  },
  "multiplayer-engineer": {
    type: "multiplayer-architecture",
    title: "Multiplayer Architecture",
    category: "systems",
  },
  "ui-designer": {
    type: "interface-system",
    title: "Interface & Accessibility System",
    category: "systems",
  },
  "performance-engineer": {
    type: "performance-report",
    title: "Performance Budget",
    category: "testing",
  },
  "balance-specialist": { type: "balance-report", title: "Balance Review", category: "testing" },
  "qa-tester": { type: "qa-report", title: "QA Report", category: "testing" },
  "game-builder": {
    type: "playable-build",
    title: "Playable Build Specification",
    category: "assets",
  },
};

const PlanSchema = z.object({
  brief: z.string(),
  userSummary: z.string(),
  tasks: z.array(
    z.object({
      agent: z.enum(specialistIds as [string, ...string[]]),
      objective: z.string(),
      dependsOn: z.array(z.string()),
    }),
  ),
});

const ReviewSchema = z.object({
  approved: z.boolean(),
  critique: z.string(),
  revisionTarget: z.string(),
  revisionInstruction: z.string(),
});

const IntelligenceSchema = z.object({
  healthScore: z.number(),
  progressPercent: z.number(),
  currentState: z.string(),
  biggestRisks: z.array(z.string()),
  missingSystems: z.array(z.string()),
  incompleteContent: z.array(z.string()),
  recommendedActions: z.array(z.string()),
});

const QUALITY_AXES = [
  "creativity",
  "gameplay",
  "replayability",
  "clarity",
  "balance",
  "feasibility",
  "enjoyment",
] as const;

const QualitySchema = z.object({
  reviews: z.array(z.object({
    discipline: z.string(),
    score: z.number(),
    summary: z.string(),
    findings: z.array(z.string()),
    axes: z.object({
      creativity: z.number(),
      gameplay: z.number(),
      replayability: z.number(),
      clarity: z.number(),
      balance: z.number(),
      feasibility: z.number(),
      enjoyment: z.number(),
    }),
  })),
});


const clampScore = (score: number) => Math.max(0, Math.min(100, Math.round(score)));
const modelGuard = () => ({ abortSignal: AbortSignal.timeout(25_000), maxOutputTokens: 4_000 });

function agentPrompt(agentId: string) {
  const agent = AGENTS.find((item) => item.id === agentId);
  if (!agent) return "You are a specialist in an autonomous game studio.";
  return `You are Derrly's ${agent.name}. ${agent.role}. Your responsibilities are: ${agent.responsibilities.join("; ")}. Produce concrete, implementation-ready work. Read all shared project memory, respect upstream decisions, identify assumptions, and explicitly describe what downstream agents need.`;
}

function messageText(message: UIMessage) {
  return message.parts.map((part) => (part.type === "text" ? part.text : "")).join("");
}

async function must<T>(promise: PromiseLike<{ data: T; error: { message: string } | null }>) {
  const result = await promise;
  if (result.error) throw new Error(result.error.message);
  if (result.data == null) throw new Error("The studio database returned no data.");
  return result.data as NonNullable<T>;
}

export async function runAutonomousStudio({
  supabase,
  projectId,
  userId,
  projectTitle,
  projectPrompt,
  messages,
}: {
  supabase: StudioClient;
  projectId: string;
  userId: string;
  projectTitle: string;
  projectPrompt: string | null;
  messages: UIMessage[];
}) {
  const groq = createGroq();
  const latestRequest = messageText(messages[messages.length - 1]);
  const [existingMemory, prefsRow] = await Promise.all([
    must(
      supabase
        .from("project_memory")
        .select("category, title, content, source_agent, version")
        .eq("project_id", projectId)
        .eq("status", "approved")
        .order("updated_at", { ascending: false })
        .limit(20),
    ),
    supabase
      .from("user_preferences")
      .select("favorite_genres, design_patterns, tone, notes")
      .eq("user_id", userId)
      .maybeSingle(),
  ]);
  const memoryContext = existingMemory.length
    ? JSON.stringify([...existingMemory].reverse()).slice(0, 32_000)
    : "No prior approved project memory exists.";
  const preferencesContext = prefsRow.data
    ? `User preferences — favorite genres: ${(prefsRow.data.favorite_genres ?? []).join(", ") || "n/a"}; tone: ${prefsRow.data.tone ?? "n/a"}; notes: ${prefsRow.data.notes ?? "n/a"}.`
    : "No saved user preferences.";

  const planResult = await generateText({
    model: groq(GROQ_MODEL),
    output: Output.object({ schema: PlanSchema }),
    system:
      "You are Derrly's Executive Producer. Convert the request into a concise project brief and a dependency-aware production task graph. Select only agents whose expertise is genuinely required. Always include creative-director, qa-tester, and game-builder. Put reviewers after the work they review. Never ask the user to manage specialists. Honor user preferences when relevant. Return valid JSON matching the provided response schema.",
    prompt: `Project: ${projectTitle}\nOriginal pitch: ${projectPrompt ?? ""}\nLatest direction: ${latestRequest}\n${preferencesContext}\nShared memory: ${memoryContext}`,
    ...modelGuard(),
  });

  const plan = planResult.output;
  if (!plan) throw new Error("The Executive Producer could not create a production plan.");

  const run = await must(
    supabase
      .from("studio_runs")
      .insert({
        project_id: projectId,
        owner_id: userId,
        status: "running",
        phase: "production",
        task_graph: plan.tasks as unknown as Json,
      })
      .select("id")
      .single(),
  );

  await must(
    supabase.from("project_memory").insert({
      project_id: projectId,
      owner_id: userId,
      category: "brief",
      title: "Executive production brief",
      content: { brief: plan.brief, request: latestRequest },
      source_agent: "executive-producer",
      status: "approved",
    }),
  );
  await must(
    supabase.from("agent_activities").insert({
      project_id: projectId,
      run_id: run.id,
      owner_id: userId,
      agent: "executive-producer",
      activity_type: "planning",
      status: "completed",
      summary: "Created the project brief and production task graph",
      details: { taskCount: plan.tasks.length },
      sequence: 0,
      completed_at: new Date().toISOString(),
    }),
  );

  const outputs = new Map<string, string>();
  for (const [index, task] of plan.tasks.entries()) {
    const agent = AGENTS.find((item) => item.id === task.agent);
    const activity = await must(
      supabase
        .from("agent_activities")
        .insert({
          project_id: projectId,
          run_id: run.id,
          owner_id: userId,
          agent: task.agent,
          activity_type:
            task.agent === "qa-tester"
              ? "review"
              : task.agent === "game-builder"
                ? "build"
                : "working",
          status: "active",
          summary: task.objective,
          details: { dependencies: task.dependsOn },
          sequence: index + 1,
        })
        .select("id")
        .single(),
    );

    const dependencyOutputs = task.dependsOn
      .map((dependency) => `${dependency}: ${outputs.get(dependency) ?? "See shared memory"}`)
      .join("\n\n");
    for (const dependency of task.dependsOn) {
      await must(
        supabase.from("agent_handoffs").insert({
          project_id: projectId,
          run_id: run.id,
          owner_id: userId,
          from_agent: dependency,
          to_agent: task.agent,
          request_type: "context",
          status: "accepted",
          context: { objective: task.objective },
          response: "Context incorporated into specialist work.",
          resolved_at: new Date().toISOString(),
        }),
      );
    }

    const generated = await generateText({
      model: groq(GROQ_MODEL),
      system: agentPrompt(task.agent),
      prompt: `PROJECT BRIEF\n${plan.brief}\n\nYOUR ASSIGNMENT\n${task.objective}\n\nAPPROVED SHARED MEMORY\n${memoryContext}\n\nUPSTREAM HANDOFFS\n${dependencyOutputs || "None — establish the foundation for downstream specialists."}\n\nReturn a polished deliverable in markdown.`,
      ...modelGuard(),
    });
    const output = generated.text;
    outputs.set(task.agent, output);
    const artifact = artifactByAgent[task.agent] ?? {
      type: "studio-output",
      title: `${agent?.name ?? "Specialist"} Deliverable`,
      category: "decision",
    };
    const memory = await must(
      supabase
        .from("project_memory")
        .insert({
          project_id: projectId,
          owner_id: userId,
          category: artifact.category,
          title: artifact.title,
          content: { markdown: output },
          source_agent: task.agent,
          status: task.agent === "qa-tester" ? "review" : "approved",
        })
        .select("id")
        .single(),
    );
    await must(
      supabase.from("project_artifacts").insert({
        project_id: projectId,
        run_id: run.id,
        owner_id: userId,
        artifact_type: artifact.type,
        title: artifact.title,
        summary: task.objective,
        content: { markdown: output },
        produced_by: task.agent,
        review_status: task.agent === "qa-tester" ? "in_review" : "approved",
      }),
    );
    await must(
      supabase
        .from("agent_activities")
        .update({ status: "completed", completed_at: new Date().toISOString() })
        .eq("id", activity.id),
    );
    for (const nextTask of plan.tasks.filter((candidate) =>
      candidate.dependsOn.includes(task.agent),
    )) {
      await must(
        supabase.from("agent_handoffs").insert({
          project_id: projectId,
          run_id: run.id,
          owner_id: userId,
          from_agent: task.agent,
          to_agent: nextTask.agent,
          request_type: "output",
          output_memory_id: memory.id,
          status: "sent",
          context: { artifact: artifact.title },
        }),
      );
    }
  }

  const reviewTargets = () => [...outputs.entries()].filter(
    ([agent]) => agent !== "qa-tester" && agent !== "game-builder",
  );
  let review: z.infer<typeof ReviewSchema> | undefined;
  let revisionCount = 0;
  const MAX_REVISIONS = 3;
  for (let cycle = 0; cycle < MAX_REVISIONS; cycle++) {
    const targets = reviewTargets();
    const reviewResult = await generateText({
      model: groq(GROQ_MODEL),
      output: Output.object({ schema: ReviewSchema }),
      system:
        "You are Derrly's QA Tester and Balance Specialist conducting a cross-discipline gate review. Approve only coherent, feasible work with consistent dependencies. If revision is needed, name the responsible agent and give one concrete correction. Return valid JSON matching the provided response schema.",
      prompt: `Brief: ${plan.brief}\n\nDeliverables:\n${targets.map(([agent, output]) => `${agent}:\n${output}`).join("\n\n")}`,
      ...modelGuard(),
    });
    review = reviewResult.output;
    if (!review) break;
    await must(
      supabase.from("agent_messages").insert({
        project_id: projectId,
        run_id: run.id,
        owner_id: userId,
        from_agent: "qa-tester",
        to_agent: review.approved ? null : review.revisionTarget,
        kind: review.approved ? "approval" : "critique",
        body: review.approved
          ? `Approved cross-discipline review for cycle ${cycle + 1}.`
          : `Cycle ${cycle + 1}: ${review.critique}`,
      }),
    );
    if (review.approved || !outputs.has(review.revisionTarget)) break;
    revisionCount++;
    await must(
      supabase.from("agent_handoffs").insert({
        project_id: projectId,
        run_id: run.id,
        owner_id: userId,
        from_agent: "qa-tester",
        to_agent: review.revisionTarget,
        request_type: "revision",
        status: "revision_requested",
        context: { critique: review.critique, instruction: review.revisionInstruction, cycle: cycle + 1 },
      }),
    );
    const revision = await generateText({
      model: groq(GROQ_MODEL),
      system: agentPrompt(review.revisionTarget),
      prompt: `Revise your deliverable in response to this review (cycle ${cycle + 1} of ${MAX_REVISIONS}).\nCritique: ${review.critique}\nRequired correction: ${review.revisionInstruction}\nPrevious deliverable:\n${outputs.get(review.revisionTarget)}`,
      ...modelGuard(),
    });
    outputs.set(review.revisionTarget, revision.text);
    await must(
      supabase.from("project_memory").insert({
        project_id: projectId,
        owner_id: userId,
        category: "revision",
        title: `${review.revisionTarget} revision cycle ${cycle + 1}`,
        content: { markdown: revision.text, critique: review.critique, cycle: cycle + 1 },
        source_agent: review.revisionTarget,
        status: "approved",
      }),
    );
    await must(
      supabase.from("agent_messages").insert({
        project_id: projectId,
        run_id: run.id,
        owner_id: userId,
        from_agent: review.revisionTarget,
        to_agent: "qa-tester",
        kind: "revision",
        body: `Submitted revision for cycle ${cycle + 1}. ${review.revisionInstruction}`,
      }),
    );
    await must(
      supabase.from("agent_activities").insert({
        project_id: projectId,
        run_id: run.id,
        owner_id: userId,
        agent: review.revisionTarget,
        activity_type: "revision",
        status: "completed",
        summary: review.revisionInstruction,
        sequence: plan.tasks.length + cycle + 1,
        completed_at: new Date().toISOString(),
      }),
    );
  }


  const evidenceText = [...outputs.entries()]
    .map(([agent, output]) => `${agent}: ${output.slice(0, 2500)}`)
    .join("\n\n");
  const [intelligenceResult, qualityResult] = await Promise.all([
    generateText({
      model: groq(GROQ_MODEL),
      output: Output.object({ schema: IntelligenceSchema }),
      system: "You are Derrly's Executive Producer reporting project intelligence. Assess only the supplied evidence. Scores must be 0-100. Identify concrete risks, gaps, incomplete content, and actionable next steps. Return valid JSON matching the schema.",
      prompt: `Brief: ${plan.brief}\nQA review: ${review?.critique ?? "Approved without critique"}\nProduction evidence:\n${evidenceText}`,
      ...modelGuard(),
    }),
    generateText({
      model: groq(GROQ_MODEL),
      output: Output.object({ schema: QualitySchema }),
      system: "You are Derrly's quality board. Score only disciplines evidenced by the supplied work. Use concise discipline names, 0-100 scores, evidence-based summaries, and concrete findings. Return valid JSON matching the schema.",
      prompt: `Project brief: ${plan.brief}\nProduction evidence:\n${evidenceText}`,
      ...modelGuard(),
    }),
  ]);
  const intelligence = intelligenceResult.output;
  const quality = qualityResult.output;
  const qualityBreakdown: Record<string, Record<string, number>> = {};
  if (quality?.reviews.length) {
    for (const item of quality.reviews) {
      qualityBreakdown[item.discipline] = Object.fromEntries(
        QUALITY_AXES.map((axis) => [axis, clampScore(item.axes[axis] ?? item.score)]),
      );
    }
  }
  const overallAxes = QUALITY_AXES.reduce<Record<string, number>>((acc, axis) => {
    const values = Object.values(qualityBreakdown).map((row) => row[axis]).filter((v) => typeof v === "number");
    acc[axis] = values.length ? clampScore(values.reduce((a, b) => a + b, 0) / values.length) : 0;
    return acc;
  }, {});
  if (intelligence) {
    await must(supabase.from("project_intelligence").insert({
      project_id: projectId,
      run_id: run.id,
      owner_id: userId,
      health_score: clampScore(intelligence.healthScore),
      progress_percent: clampScore(intelligence.progressPercent),
      completion_percent: clampScore(intelligence.progressPercent),
      current_state: intelligence.currentState,
      biggest_risks: intelligence.biggestRisks,
      missing_systems: intelligence.missingSystems,
      incomplete_content: intelligence.incompleteContent,
      recommended_actions: intelligence.recommendedActions,
      quality_breakdown: { axes: overallAxes, byDiscipline: qualityBreakdown } as unknown as Json,
      evidence: { review: review?.critique ?? "Approved", agents: [...outputs.keys()] },
    }));
  }
  if (quality?.reviews.length) {
    await must(supabase.from("quality_reviews").insert(quality.reviews.map((item) => ({
      project_id: projectId,
      run_id: run.id,
      owner_id: userId,
      discipline: item.discipline,
      score: clampScore(item.score),
      status: item.score >= 80 ? "approved" : "revision_requested",
      summary: item.summary,
      findings: item.findings,
      axes: qualityBreakdown[item.discipline] as unknown as Json,
      evidence: { sourceAgents: [...outputs.keys()] },
    }))));
  }

  const builderOutput = outputs.get("game-builder") ?? "Build specification pending.";
  await must(supabase.from("build_records").insert({
    project_id: projectId,
    run_id: run.id,
    owner_id: userId,
    status: "specification",
    gameplay_overview: outputs.get("gameplay-engineer")?.slice(0, 1800) ?? plan.brief,
    core_loop: outputs.get("creative-director")?.slice(0, 1800) ?? plan.brief,
    world_overview: outputs.get("world-architect")?.slice(0, 1800) ?? "World design not included in this cycle.",
    quest_overview: outputs.get("quest-designer")?.slice(0, 1800) ?? "Quest design not included in this cycle.",
    manifest: { type: "design-specification", agents: [...outputs.keys()], builderSpecification: builderOutput.slice(0, 4000) },
    logs: ["Production artifacts assembled", "Cross-discipline review completed", "Build specification recorded"],
  }));
  await must(supabase.from("project_events").insert([
    { project_id: projectId, run_id: run.id, owner_id: userId, actor_type: "agent", actor: "executive-producer", event_type: "brief_created", summary: "Executive Producer created the production brief", details: { taskCount: plan.tasks.length } },
    ...plan.tasks.map((task) => ({ project_id: projectId, run_id: run.id, owner_id: userId, actor_type: "agent", actor: task.agent, event_type: task.agent === "qa-tester" ? "qa_completed" : task.agent === "game-builder" ? "build_specified" : "deliverable_completed", summary: `${AGENTS.find((agent) => agent.id === task.agent)?.name ?? task.agent} completed ${task.objective}`, details: { dependencies: task.dependsOn } })),
    { project_id: projectId, run_id: run.id, owner_id: userId, actor_type: "agent", actor: "executive-producer", event_type: "run_approved", summary: "Executive Producer approved the production cycle", details: { revised: Boolean(review && !review.approved) } },
  ]));

  await must(
    supabase
      .from("studio_runs")
      .update({
        status: "completed",
        phase: "approved",
        revision_count: revisionCount,
        completed_at: new Date().toISOString(),
      })
      .eq("id", run.id),
  );
  await must(supabase.from("projects").update({ status: "ready" }).eq("id", projectId));
  await must(
    supabase.from("agent_activities").insert({
      project_id: projectId,
      run_id: run.id,
      owner_id: userId,
      agent: "executive-producer",
      activity_type: "approval",
      status: "completed",
      summary: "Cross-discipline review complete — production package approved",
      sequence: plan.tasks.length + 2,
      completed_at: new Date().toISOString(),
    }),
  );

  const completedAgents = plan.tasks
    .map((task) => AGENTS.find((agent) => agent.id === task.agent)?.name ?? task.agent)
    .join(", ");
  return `## Production cycle approved\n\n${plan.userSummary}\n\n**Studio team deployed:** ${completedAgents}.\n\nI created ${plan.tasks.length} specialist deliverables, coordinated handoffs, ran ${revisionCount > 0 ? `${revisionCount} autonomous revision ${revisionCount === 1 ? "cycle" : "cycles"}` : "a clean cross-discipline review"} and approved the unified production package. Open **Artifacts** to inspect the work, **Quality** for the multi-axis scorecard, or **War Room** for the agent conversation.`;
}
